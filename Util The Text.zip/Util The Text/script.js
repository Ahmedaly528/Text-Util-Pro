// ✅ Convert Text Functions
function convertToUppercase() {
    document.getElementById("textArea").value = document.getElementById("textArea").value.toUpperCase();
}

function convertToLowercase() {
    document.getElementById("textArea").value = document.getElementById("textArea").value.toLowerCase();
}

function convertToSentenceCase() {
    let text = document.getElementById("textArea").value.toLowerCase();
    document.getElementById("textArea").value = text.charAt(0).toUpperCase() + text.slice(1);
}

function reverseText() {
    document.getElementById("textArea").value = document.getElementById("textArea").value.split("").reverse().join("");
}
// Extraction functions
function extractNumbers() {
    const text = document.getElementById("textArea").value;
    const numbers = text.match(/\d+(\.\d+)?/g);
    if (numbers) {
        document.getElementById("textArea").value = numbers.join(", ");
    } else {
        document.getElementById("textArea").value = "No numbers found!";
    }
}

function extractLinks() {
    const text = document.getElementById("textArea").value;
    const links = text.match(/(https?:\/\/[^\s]+)/g);
    if (links) {
        document.getElementById("textArea").value = links.join("\n");
    } else {
        document.getElementById("textArea").value = "No links found!";
    }
}
// ✅ Copy & Paste
function copyToClipboard() {
    let textArea = document.getElementById("textArea");
    textArea.select();
    document.execCommand("copy");
    alert("Copied to clipboard!");
}

function pasteFromClipboard() {
    navigator.clipboard.readText().then((text) => {
        document.getElementById("textArea").value = text;
    });
}

// ✅ Grammar Check
async function checkGrammar() {
    let text = document.getElementById("textArea").value;
    let response = await fetch("https://api.languagetool.org/v2/check", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `text=${encodeURIComponent(text)}&language=en-US`,
    });
    let result = await response.json();
    alert(result.matches.length ? "Grammar issues found!" : "No grammar issues!");
}

// ✅ Translation
async function translateText() {
    const text = document.getElementById("textArea").value;
    const targetLang = document.getElementById("languageSelect").value;

    if (!text.trim()) {
        alert("Please enter some text to translate!");
        return;
    }

    try {
        const response = await fetch(
            `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|${targetLang}`
        );

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const result = await response.json();
        if (result.responseData && result.responseData.translatedText) {
            document.getElementById("textArea").value = result.responseData.translatedText;
        } else {
            throw new Error("Translation failed: No translated text found.");
        }
    } catch (error) {
        console.error("Translation error:", error);
        alert("Translation failed. Please try again later.");
    }
}
// ✅ Text-to-Speech
function readTextAloud() {
    let speech = new SpeechSynthesisUtterance(document.getElementById("textArea").value);
    speech.lang = "en-US";
    speechSynthesis.speak(speech);
}

// ✅ Speech-to-Text
function startVoiceInput() {
    let recognition = new webkitSpeechRecognition();
    recognition.lang = "en-US";
    recognition.start();
    recognition.onresult = (event) => {
        document.getElementById("textArea").value = event.results[0][0].transcript;
    };
}

// ✅ Undo Redo (Fixed)
let history = [""];
let index = 0;

document.addEventListener("DOMContentLoaded", function () {
    let textArea = document.getElementById("textArea");

    // Save the initial state
    saveState();

    // Listen for input changes to track history
    textArea.addEventListener("input", function () {
        saveState();
    });
});

function saveState() {
    let textArea = document.getElementById("textArea");

    // Prevent duplicate consecutive states
    if (history[index] !== textArea.value) {
        history = history.slice(0, index + 1); // Trim future redo states
        history.push(textArea.value);
        index++;
    }
}

function undo() {
    if (index > 0) {
        index--;
        document.getElementById("textArea").value = history[index];
    }
}

function redo() {
    if (index < history.length - 1) {
        index++;
        document.getElementById("textArea").value = history[index];
    }
}

// ✅ Text Summarization
document.addEventListener("DOMContentLoaded", function () {
    let textArea = document.getElementById("textArea");

    // Listen for input changes and update summary
    textArea.addEventListener("input", updateSummary);
});

function updateSummary() {
    let text = document.getElementById("textArea").value.trim();

    let wordCount = text.split(/\s+/).filter(word => word.length > 0).length;
    let charCount = text.length;
    let sentenceCount = text.split(/[.!?]+/).filter(sentence => sentence.trim().length > 0).length;
    let readingTime = Math.ceil(wordCount / 200); // Assuming 200 words per minute reading speed

    document.getElementById("wordCount").innerText = `${wordCount} words, ${charCount} characters`;
    document.getElementById("readingTime").innerText = `${readingTime} Minute${readingTime !== 1 ? "s" : ""} read`;
}


// ✅ Dark Mode
document.addEventListener("DOMContentLoaded", function () {
    const darkModeToggle = document.getElementById("darkModeToggle");
    const body = document.body;

    // Check if dark mode was enabled previously
    if (localStorage.getItem("theme") === "dark") {
        body.classList.add("dark-mode");
        darkModeToggle.checked = true;
    }

    // Toggle dark mode on checkbox change
    darkModeToggle.addEventListener("change", function () {
        if (this.checked) {
            body.classList.add("dark-mode");
            localStorage.setItem("theme", "dark");
        } else {
            body.classList.remove("dark-mode");
            localStorage.setItem("theme", "light");
        }
    });
});


document.getElementById("translateBtn").addEventListener("click", translateText);
document.getElementById("speakBtn").addEventListener("click", readTextAloud);
document.getElementById("voiceInputBtn").addEventListener("click", startVoiceInput);
